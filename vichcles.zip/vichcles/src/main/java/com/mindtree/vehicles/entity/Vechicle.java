package com.mindtree.vehicles.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="vechicle")
public class Vechicle {
	
	@Id
	@Column(name="vechicleId")
	private String vechicleId;
	
	@Column(name="vechicleName")
	private String vechicleName;
	
	@Column(name="vechicleState")
	private String vechicleState;
	
	@Column(name="vechicleCountry")
	private String vechicleCountry;
	
	@ManyToOne(cascade=CascadeType.ALL)
	private User users;

	public Vechicle() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Vechicle(String vechicleId, String vechicleName, String vechicleState, String vechicleCountry, User users) {
		super();
		this.vechicleId = vechicleId;
		this.vechicleName = vechicleName;
		this.vechicleState = vechicleState;
		this.vechicleCountry = vechicleCountry;
		this.users = users;
	}

	public String getVechicleId() {
		return vechicleId;
	}

	public void setVechicleId(String vechicleId) {
		this.vechicleId = vechicleId;
	}

	public String getVechicleName() {
		return vechicleName;
	}

	public void setVechicleName(String vechicleName) {
		this.vechicleName = vechicleName;
	}

	public String getVechicleState() {
		return vechicleState;
	}

	public void setVechicleState(String vechicleState) {
		this.vechicleState = vechicleState;
	}

	public String getVechicleCountry() {
		return vechicleCountry;
	}

	public void setVechicleCountry(String vechicleCountry) {
		this.vechicleCountry = vechicleCountry;
	}

	public User getUsers() {
		return users;
	}

	public void setUsers(User users) {
		this.users = users;
	}

	

}
