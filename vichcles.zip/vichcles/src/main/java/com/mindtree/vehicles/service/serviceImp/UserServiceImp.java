package com.mindtree.vehicles.service.serviceImp;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.vehicles.entity.User;
import com.mindtree.vehicles.repository.Userrepository;
import com.mindtree.vehicles.service.UserService;
@Service
public class UserServiceImp implements UserService{
	
	@Autowired
	Userrepository userRepository;

	@Override
	public void addUserdetails(User user) {
		userRepository.save(user);		
	}

	@Override
	public List<User> getUsers() {
		List<User> users=userRepository.findAll();
		return users;
	}

	@Override
	public List<User> getAllVechicle() {
		List<User> users=userRepository.findAll();
		
		Collections.sort(users,new Comparator<User>() {
			 public int compare(User a1, User a2) {
			        return a2.getVechicles().size() - a1.getVechicles().size(); 
			 }// assumes you want biggest to smallest
			    });

			
		return users;
		}
	}


