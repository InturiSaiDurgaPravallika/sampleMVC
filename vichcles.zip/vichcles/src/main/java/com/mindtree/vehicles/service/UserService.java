package com.mindtree.vehicles.service;

import java.util.List;

import com.mindtree.vehicles.entity.User;

public interface UserService {

public	void addUserdetails(User user);

public List<User> getUsers();

public List<User> getAllVechicle();

}
