package com.mindtree.vehicles.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.vehicles.entity.User;
import com.mindtree.vehicles.entity.Vechicle;
import com.mindtree.vehicles.service.UserService;
import com.mindtree.vehicles.service.VechicleService;

@Controller
public class AppController {
	
	@Autowired
	 private UserService userService;
	
	@Autowired
	private VechicleService vechicleService;
	
	
	@RequestMapping("/index")
	public String index()
	{
		return "index";
	}
	
	@RequestMapping("/user")
	public String addDetailsValues()
	{
		return "user";
	}
	
	@RequestMapping("/display")
	public  String addUserDetails(@ModelAttribute User user,Model model) {
	userService.addUserdetails(user);
	return "index";
	}
	
	@RequestMapping("/vechicle")
	public String addVechicleValues(Model model)
	{
		List<User> list=userService.getUsers();
		model.addAttribute("list", list);
		return "vechicle";
	}
	
	@RequestMapping("/dis")
	public  String addVechicleDetails(@ModelAttribute Vechicle vechicles,Model model,@RequestParam int userId) {
	vechicleService.addVechicleDetails(vechicles,userId);
	return "index";
	}
	
	@RequestMapping("/view")
	public String getAllVechicle(Model model)
	{
		List<User> list=userService.getAllVechicle();
		model.addAttribute("list", list);
		return "view";
	}

}
