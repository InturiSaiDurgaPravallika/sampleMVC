package com.mindtree.vehicles.service;

import com.mindtree.vehicles.entity.Vechicle;

public interface VechicleService {

public	void addVechicleDetails(Vechicle vechicles, int userId);

}
