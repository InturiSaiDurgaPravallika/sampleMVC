package com.mindtree.vehicles.service.serviceImp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.vehicles.entity.User;
import com.mindtree.vehicles.entity.Vechicle;
import com.mindtree.vehicles.repository.Userrepository;
import com.mindtree.vehicles.repository.Vechiclerepository;
import com.mindtree.vehicles.service.VechicleService;
@Service
public class VechicelServiceImp implements VechicleService{
	
	@Autowired
	Vechiclerepository vechiclerepository;
	
	@Autowired
	Userrepository userRepository;

	@Override
	public void addVechicleDetails(Vechicle vechicles, int userId) {
		User users=userRepository.findById(userId).get();
		String vechicleid=vechicles.getVechicleName().substring(0, 1)+vechicles.getVechicleCountry().substring(0, 1)+vechicles.getVechicleState().substring(0, 2);
		vechicles.setVechicleId(vechicleid);
	
		vechicles.setUsers(users);
	vechiclerepository.save(vechicles);
		
	}

}
